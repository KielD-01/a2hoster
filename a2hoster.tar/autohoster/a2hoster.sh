#!/bin/bash
# Need to add Source to use functions
reset
source  a2hoster.func.sh

checkRoot
showMenu
